import itertools
import pickle

from Bio import SeqIO

def main():
    kmer_length = 4
    all_kmers = [''.join(kmer) for kmer
                 in itertools.product("ACTG", repeat=kmer_length)]
    kmer_locations = {}
    
    # Assume there's only one chromosome:
    record = list(SeqIO.parse("ecoli.fasta", "fasta"))[0]
    seq = str(record.seq)
    
    for kmer in all_kmers:
        kmer_locations[kmer] = find_kmer(seq, kmer)
        
    # Store the data in Python's binary format for later processing:
    with open("kmer_locations.dat", "wb") as output_file:
        pickle.dump(kmer_locations, output_file)
    
def find_kmer(seq, kmer):
    # Given a sequence and a kmer, return a list will all the indexes in the
    # sequence where the kmer appears.
    ixes = []
    for ix in range(len(seq)):
        if seq[ix:ix+len(kmer)] == kmer:
            ixes.insert(0, ix)

    return ixes

if __name__ == "__main__":
    main()
